import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { useTrading } from '@/contexts/TradingContext';
import {
  Brain, LayoutDashboard, Activity, Link2, Settings, Menu, LogOut, User,
  ChevronDown, Bot, Clock, Terminal, BarChart2, Globe
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const NAV_ITEMS = [
  { path: '/',           label: 'Dashboard',           icon: LayoutDashboard },
  { path: '/ai-signals', label: 'AI Signals',          icon: Activity },
  { path: '/exchange',   label: 'Exchange Connections', icon: Link2 },
  { path: '/settings',   label: 'Settings',            icon: Settings },
];

// Detail views — shown as secondary nav group (not permanently prominent)
const DETAIL_ITEMS = [
  { path: '/pipeline',       label: 'Pipeline Diagnostics', icon: Terminal },
  { path: '/ai-performance', label: 'AI Performance',       icon: BarChart2 },
  { path: '/market',         label: 'Market Overview',      icon: Globe },
];

// ─── System Status Panel (desktop header) ────────────────────────────────────
function SystemStatus() {
  const { marketDataStatus, pionexAccountStatus, aiAnalysisStatus, lastAIUpdate, signalsCache } = useTrading();

  const getOpenAIStatus = () => {
    if (aiAnalysisStatus === 'updating') return { label: 'ANALYZING', color: 'text-warning', live: false };
    const openaiStatus = signalsCache?.gemini_status;
    if (openaiStatus === 'connected') return { label: 'READY', color: 'text-success', live: true };
    if (openaiStatus === 'RATE_LIMIT') return { label: 'RATE LIMITED', color: 'text-warning', live: false };
    if (openaiStatus === 'AUTH_ERROR') return { label: 'AUTH ERROR', color: 'text-destructive', live: false };
    if (openaiStatus === 'NOT_CONFIGURED') return { label: 'NOT CONFIGURED', color: 'text-destructive', live: false };
    if (openaiStatus === 'OFFLINE' || openaiStatus === 'NETWORK_ERROR') return { label: 'OFFLINE', color: 'text-destructive', live: false };
    if (openaiStatus && openaiStatus !== 'connected') return { label: openaiStatus.replace(/_/g, ' ').toUpperCase(), color: 'text-destructive', live: false };
    if (aiAnalysisStatus === 'error') return { label: 'DOWN', color: 'text-destructive', live: false };
    if (!lastAIUpdate) return { label: 'NOT RUN', color: 'text-muted-foreground', live: false };
    return { label: 'READY', color: 'text-success', live: true };
  };

  const getAILabel = () => {
    if (aiAnalysisStatus === 'updating') return 'Analyzing...';
    if (aiAnalysisStatus === 'error') return 'Unavailable';
    if (!lastAIUpdate) return 'Not run';
    const mins = Math.floor((Date.now() - lastAIUpdate.getTime()) / 60000);
    return mins < 1 ? 'Just now' : `${mins}m ago`;
  };

  const openai = getOpenAIStatus();
  return (
    <div className="flex items-center gap-3 flex-1 min-w-0 overflow-x-hidden">
      {[
        {
          label: 'Pionex',
          value: marketDataStatus === 'live' ? 'LIVE' : marketDataStatus === 'cached' ? 'CACHED' : 'DOWN',
          color: marketDataStatus === 'live' ? 'text-success' : marketDataStatus === 'cached' ? 'text-warning' : 'text-destructive',
          live: marketDataStatus === 'live',
        },
        {
          label: 'Account',
          value: pionexAccountStatus === 'connected' ? 'CONNECTED' : 'OFFLINE',
          color: pionexAccountStatus === 'connected' ? 'text-success' : 'text-muted-foreground',
          live: pionexAccountStatus === 'connected',
        },
        {
          label: 'OpenAI',
          value: openai.label,
          color: openai.color,
          live: openai.live,
        },
        {
          label: 'Last AI',
          value: getAILabel(),
          color: 'text-foreground',
          live: false,
        },
      ].map((s, i) => (
        <div key={s.label} className="flex items-center gap-2 min-w-0 shrink-0">
          {i > 0 && <div className="w-px h-3 bg-border shrink-0" />}
          <span className="text-muted-foreground text-xs hidden lg:inline shrink-0">{s.label}:</span>
          <span className={cn('text-xs font-semibold flex items-center gap-1 shrink-0', s.color)}>
            {s.live && <span className="status-dot-live" />}
            {s.value}
          </span>
        </div>
      ))}
    </div>
  );
}

function NavItem({ item, active, onClick }: { item: typeof NAV_ITEMS[0]; active: boolean; onClick?: () => void }) {
  const Icon = item.icon;
  return (
    <Link to={item.path} onClick={onClick}
      className={cn(
        'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all',
        active
          ? 'text-primary-foreground'
          : 'text-sidebar-foreground hover:text-foreground hover:bg-sidebar-accent'
      )}
      style={active ? { background: 'var(--gradient-primary)', boxShadow: 'var(--glow-purple)' } : {}}>
      <Icon className="w-4 h-4 shrink-0" />
      <span>{item.label}</span>
    </Link>
  );
}

function SidebarContent({ onNavClick }: { onNavClick?: () => void }) {
  const location = useLocation();
  const { aiAnalysisStatus, lastAIUpdate, marketDataStatus, pionexAccountStatus, signalsCache } = useTrading();

  const getOpenAIStatus = () => {
    if (aiAnalysisStatus === 'updating') return { label: 'ANALYZING', color: 'text-warning', dot: false };
    const openaiStatus = signalsCache?.gemini_status;
    if (openaiStatus === 'connected') return { label: 'READY', color: 'text-success', dot: true };
    if (openaiStatus === 'RATE_LIMIT') return { label: 'RATE LIMITED', color: 'text-warning', dot: false };
    if (openaiStatus === 'AUTH_ERROR') return { label: 'AUTH ERROR', color: 'text-destructive', dot: false };
    if (openaiStatus === 'NOT_CONFIGURED') return { label: 'NOT CONFIGURED', color: 'text-destructive', dot: false };
    if (openaiStatus === 'OFFLINE' || openaiStatus === 'NETWORK_ERROR') return { label: 'OFFLINE', color: 'text-destructive', dot: false };
    if (openaiStatus && openaiStatus !== 'connected') return { label: openaiStatus.replace(/_/g, ' ').toUpperCase(), color: 'text-destructive', dot: false };
    if (aiAnalysisStatus === 'error') return { label: 'DOWN', color: 'text-destructive', dot: false };
    if (!lastAIUpdate) return { label: 'NOT RUN', color: 'text-muted-foreground', dot: false };
    return { label: 'READY', color: 'text-success', dot: true };
  };

  const getAIStatusText = () => {
    if (aiAnalysisStatus === 'updating') return 'Updating...';
    if (!lastAIUpdate) return 'Not yet run';
    const mins = Math.floor((Date.now() - lastAIUpdate.getTime()) / 60000);
    if (mins < 1) return 'Just now';
    return `${mins}m ago`;
  };

  const openai = getOpenAIStatus();

  return (
    <div className="flex flex-col h-full bg-sidebar py-4 px-3">
      {/* Logo */}
      <div className="flex items-center gap-3 px-2 mb-8">
        <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: 'var(--gradient-primary)', boxShadow: 'var(--glow-purple)' }}>
          <Brain className="w-5 h-5 text-white" />
        </div>
        <div className="min-w-0">
          <div className="text-sm font-bold text-foreground font-['Space_Grotesk'] truncate">TradeMindMZ</div>
          <div className="text-xs text-muted-foreground truncate">AI Trading Assistant</div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1">
        {NAV_ITEMS.map(item => (
          <NavItem key={item.path} item={item} active={location.pathname === item.path} onClick={onNavClick} />
        ))}

        {/* Detail views — secondary group */}
        <div className="pt-3 mt-2 border-t border-sidebar-border">
          <div className="px-3 mb-1.5">
            <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Analysis</span>
          </div>
          {DETAIL_ITEMS.map(item => (
            <NavItem key={item.path} item={item} active={location.pathname === item.path} onClick={onNavClick} />
          ))}
        </div>
      </nav>

      {/* System Status Panel — 4 indicators */}
      <div className="mt-4 p-3 rounded-lg border border-border space-y-2" style={{ background: 'hsl(var(--muted))' }}>
        <div className="text-xs font-semibold text-foreground mb-1">System Status</div>

        {[
          {
            label: 'Pionex Market',
            icon: <Activity className="w-3 h-3" />,
            value: marketDataStatus === 'live' ? 'LIVE' : marketDataStatus === 'cached' ? 'CACHED' : 'DOWN',
            color: marketDataStatus === 'live' ? 'text-success' : marketDataStatus === 'cached' ? 'text-warning' : 'text-destructive',
            dot: marketDataStatus === 'live',
          },
          {
            label: 'Pionex Account',
            icon: <Link2 className="w-3 h-3" />,
            value: pionexAccountStatus === 'connected' ? 'CONNECTED' : 'NOT CONNECTED',
            color: pionexAccountStatus === 'connected' ? 'text-success' : 'text-muted-foreground',
            dot: pionexAccountStatus === 'connected',
          },
          {
            label: 'OpenAI',
            icon: <Bot className="w-3 h-3" />,
            value: openai.label,
            color: openai.color,
            dot: openai.dot,
          },
          {
            label: 'Last AI Analysis',
            icon: <Clock className="w-3 h-3" />,
            value: getAIStatusText(),
            color: 'text-foreground',
            dot: false,
          },
        ].map(s => (
          <div key={s.label} className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-muted-foreground text-xs min-w-0">
              {s.icon}
              <span className="truncate">{s.label}</span>
            </div>
            <div className={cn('text-xs font-semibold flex items-center gap-1 shrink-0', s.color)}>
              {s.dot && <span className="status-dot-live" />}
              {s.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    toast.success('Signed out successfully');
    navigate('/login');
  };

  const displayName = profile?.display_name || profile?.username || user?.email?.split('@')[0] || 'User';
  const initials = displayName.slice(0, 2).toUpperCase();
  const currentPage = [...NAV_ITEMS, ...DETAIL_ITEMS].find(n => n.path === location.pathname)?.label ?? 'TradeMindMZ';

  return (
    <div className="flex min-h-screen w-full">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-60 shrink-0 border-r border-sidebar-border">
        <SidebarContent />
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col overflow-x-hidden">
        {/* Top header */}
        <header className="sticky top-0 z-40 flex items-center gap-2 px-3 md:px-4 h-14 border-b border-border"
          style={{ background: 'hsl(var(--background) / 0.95)', backdropFilter: 'blur(8px)' }}>

          {/* Mobile hamburger — md:hidden ensures it disappears on desktop */}
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden shrink-0 w-9 h-9">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 bg-sidebar border-sidebar-border">
              <SidebarContent onNavClick={() => setMobileOpen(false)} />
            </SheetContent>
          </Sheet>

          {/* Mobile page title — truncated, never overflows */}
          <span className="font-semibold text-sm text-foreground truncate flex-1 min-w-0 md:hidden">{currentPage}</span>

          {/* Desktop: system status bar (hidden on mobile — too many items for small screen) */}
          <div className="hidden md:flex flex-1 min-w-0 overflow-hidden">
            <SystemStatus />
          </div>

          {/* User menu — always visible, shrinks name on small screens */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-1.5 h-9 px-2 shrink-0">
                <Avatar className="w-7 h-7 shrink-0">
                  <AvatarFallback className="text-xs font-bold text-primary-foreground"
                    style={{ background: 'var(--gradient-primary)' }}>
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden md:block text-sm font-medium max-w-24 truncate">{displayName}</span>
                <ChevronDown className="w-3.5 h-3.5 text-muted-foreground hidden md:block shrink-0" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => navigate('/settings')}>
                <User className="w-4 h-4 mr-2" /> Profile & Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                <LogOut className="w-4 h-4 mr-2" /> Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        {/* Page content — overflow-y-auto with pb-4 ensures footer always visible */}
        <main className="flex-1 overflow-y-auto min-h-0">
          {children}
        </main>

        {/* Footer — always at bottom, readable on mobile */}
        <footer className="px-4 py-2 border-t border-border shrink-0">
          <p className="text-[10px] md:text-xs text-muted-foreground text-center leading-relaxed">
            TradeMindMZ — AI market analysis. Data: Pionex. AI: OpenAI. Not financial advice.
          </p>
        </footer>
      </div>
    </div>
  );
}
